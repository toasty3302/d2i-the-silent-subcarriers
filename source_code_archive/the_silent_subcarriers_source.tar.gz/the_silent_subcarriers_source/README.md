# the_silent_subcarriers — Source Code Archive

Single archive of source code for all tasks (0–3).
Runnable on **Ubuntu 22.04 with CUDA 12**.

## Setup

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

`requirements.txt` at this top level is the union of all task dependencies.
Each `final_submission_taskN/` also contains its own `packages.txt` with the
minimal per-task dependency set and notes.

## Contents

- `final_submission_task0/` — source (`the_silent_subcarriers_0.py`, `prep_data.py`), README, solution notes
- `final_submission_task1/` — source, README, solution notes, input `data/`, `submission.csv`
- `final_submission_task2/` — source, README, solution notes, proposed config JSONs
- `final_submission_task3/` — source, README, solution notes, `config.yaml`

## Not included (linked separately — see the next question)

Large model weights are intentionally excluded from this source archive:

- `final_submission_task0/models/the_silent_subcarriers_0.pth` (~29 MB)
- `final_submission_task3/models/the_silent_subcarriers_3.pkl` (~65 MB)

Also excluded: `final_submission_task0/submission.csv` (~63 MB generated
prediction output) and all `__pycache__/` directories.
